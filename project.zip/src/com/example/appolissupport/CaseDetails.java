package com.example.appolissupport;

import java.util.ArrayList;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import com.handmark.pulltorefresh.library.PullToRefreshSwipeListView;
import com.support.adapters.CasesAdapter;
import com.support.adapters.DetailsAdapter;
import com.support.objects.Details;
import com.support.utilities.Constants;

import android.R.integer;
import android.R.string;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Point;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class CaseDetails extends Activity implements OnClickListener, OnItemClickListener, OnCheckedChangeListener  {
	
	private final String METHOD_NAME = "GetCaseDetails";
	private final String SOAP_ACTION = Constants.NAMESPACE+METHOD_NAME;
	public static String TAG = "PGGURU";
	private String caseNumber;
	private static ListView lvDetailsList;
	private Button btnSubmit;
	private Runnable fitsOnScreen;
	private int totalListHeight;
	private int totalScreenHeight;
	private ArrayList<Details> listItemInfo = new ArrayList<Details>();
	private DetailsAdapter detailsAdapter = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_case_details);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		
		lvDetailsList = (ListView)findViewById(R.id.case_details_list);
		lvDetailsList.setOnItemClickListener(this);
		
		btnSubmit = (Button)findViewById(R.id.btn_submit_response);
		btnSubmit.setOnClickListener(this);
		Bundle bundle = getIntent().getExtras();
		if(bundle != null){
			if (bundle.containsKey("CaseID")) {
				caseNumber = bundle.get("CaseID").toString();
			
			}
		}
		refresh(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.case_details, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	 public void refresh(Context context) {
 		AsyncCallWS mLoadDataTask = new AsyncCallWS(context);

 		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
 			mLoadDataTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
 		} else {
 			mLoadDataTask.execute();
 		}
 	}

	private class AsyncCallWS extends AsyncTask<String, Void, Void> {
       
		Context context;
		ProgressDialog progressDialog;

		public AsyncCallWS(Context mContext){
			this.context = mContext;

		}

		@Override
		protected void onPreExecute() {
			listItemInfo.clear();
			super.onPreExecute();
			if(!isCancelled()){
				progressDialog = new ProgressDialog(context);
				progressDialog.setMessage("Loading...");
				progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
	
							@Override
							public void onCancel(DialogInterface dialog) {
								cancel(true);
							}
						});
				progressDialog.setCanceledOnTouchOutside(false);
				progressDialog.setCancelable(false);
				progressDialog.show();
			}
			
		}
		
		@Override
        protected Void doInBackground(String... params) {
    	    SoapObject request = new SoapObject(Constants.NAMESPACE, METHOD_NAME);
    	    //Property which holds input parameters
    	    PropertyInfo supportCasesPI = new PropertyInfo();
    	    supportCasesPI.setName("iCaseID");
    	    supportCasesPI.setValue(caseNumber);
    	    supportCasesPI.setType(String.class);
    	    request.addProperty(supportCasesPI);
    	    
    	   

    	    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
    	            SoapEnvelope.VER11);
    	    envelope.dotNet = true;
    	    //Set output SOAP object
    	    envelope.setOutputSoapObject(request);
    	    //Create HTTP call object
    	    HttpTransportSE androidHttpTransport = new HttpTransportSE(Constants.URL);
    	 
    	    try {
    	        //Invole web service
    	        androidHttpTransport.call(SOAP_ACTION, envelope);
                SoapObject response = (SoapObject) envelope.getResponse();
                for (int i = 0; i < response.getPropertyCount(); i++) {

                    Object property = response.getProperty(i);
                    SoapObject info = (SoapObject) property;
                    Details cds = new Details();
                    cds.setUserID(Integer.valueOf(info.getProperty("UserID").toString().trim()));
                    cds.setSupportUserID(Integer.valueOf(info.getProperty("SupportUserID").toString().trim()));
                    cds.setDateCreated(info.getProperty("DateCreated").toString().trim());
                    cds.setName(info.getProperty("Name").toString().trim());
                    String strippedResponse = info.getProperty("Response").toString().trim().replaceAll("\\<.*?>","");
                    cds.setResponse(strippedResponse);
                    cds.setResponse(info.getProperty("Response").toString().trim());
                    cds.setSubject(info.getProperty("Subject").toString().trim());
                    listItemInfo.add(cds);
                    
                    
                }
    	 
    	    } catch (Exception e) {
    	        e.printStackTrace();
    	    }
            return null;
        }
 
        @Override
        protected void onPostExecute(Void result) {
            Log.i(TAG, "onPostExecute");
            if(null != progressDialog && (progressDialog.isShowing())){
				progressDialog.dismiss();
			}
            
            
            detailsAdapter = new DetailsAdapter(context,
    				listItemInfo);
            lvDetailsList.setAdapter(detailsAdapter);
           
           
            detailsAdapter.notifyDataSetChanged();
            fitsOnScreen = new Runnable() {
                @Override
                public void run() {
            		int abc = getTotalHeightofListView(lvDetailsList);
            		Display display = getWindowManager().getDefaultDisplay();
            		Point size = new Point();
            		display.getSize(size);
            		int height = size.y;
            		
            		if(abc * 2.5 > height){
            			lvDetailsList.setSelection(lvDetailsList.getCount() - 1);
            		}
                }
            };
			
            lvDetailsList.post(fitsOnScreen);
          
        }
        
       
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
	
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btn_submit_response:
			Toast.makeText(this, "this is my Toast message!!! =)",
					   Toast.LENGTH_LONG).show();
			
			break;
		default:
			break;
	}
		
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		
	}
	
	
	public static int getTotalHeightofListView(ListView listView) {

		ListAdapter mAdapter = listView.getAdapter();
			
		int a = listView.getHeight();
	    int totalHeight = 0;

	    for (int i = 0; i < mAdapter.getCount(); i++) {
	        View mView = mAdapter.getView(i, null, listView);

	        mView.measure(
	                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),

	                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));

	        totalHeight += mView.getMeasuredHeight();
	        Log.w("HEIGHT" + i, String.valueOf(totalHeight));

	    }

	    ViewGroup.LayoutParams params = listView.getLayoutParams();
	    params.height = totalHeight
	            + (listView.getDividerHeight() * (mAdapter.getCount() - 1));
	    listView.setLayoutParams(params);
	    listView.requestLayout();
	    return totalHeight;

	}
}
