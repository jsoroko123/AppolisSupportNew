package com.example.appolissupport;

import java.util.ArrayList;

import javax.security.auth.PrivateCredentialPermission;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import com.support.adapters.CasesAdapter;
import com.support.fragments.CasesFragment;
import com.support.fragments.ClientsFragment;
import com.support.fragments.ErrorsFragment;
import com.support.fragments.HomeFragment;
import com.support.fragments.SubmitFragment;
import com.support.objects.SupportCases;
import com.support.utilities.Constants;
import com.support.utilities.SharedPreferenceManager;

import android.app.Activity;
import android.app.ActionBar;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.support.v4.widget.DrawerLayout;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.CompoundButton.OnCheckedChangeListener;


public class MainActivity extends Activity implements 


		NavigationDrawerFragment.NavigationDrawerCallbacks {

	/**
	 * Fragment managing the behaviors, interactions and presentation of the
	 * navigation drawer.
	 */
	private NavigationDrawerFragment mNavigationDrawerFragment;

	/**
	 * Used to store the last screen title. For use in
	 * {@link #restoreActionBar()}.
	 */

	private CharSequence mTitle;
	public static String FragPageTitle;
	private final String METHOD_NAME = "ListClients";
	private final String SOAP_ACTION = Constants.NAMESPACE+METHOD_NAME;
	private ArrayList<String> listItemInfo = new ArrayList<String>();
	private ArrayList<String> listItemInfo2 = new ArrayList<String>();
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mNavigationDrawerFragment = (NavigationDrawerFragment) getFragmentManager()
				.findFragmentById(R.id.navigation_drawer);
		mTitle = getTitle();
		// Set up the drawer.
		
		mNavigationDrawerFragment.setUp(R.id.navigation_drawer,
				(DrawerLayout) findViewById(R.id.drawer_layout));
		AsyncCallWS mLoadDataTask = new AsyncCallWS(getApplicationContext());
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			mLoadDataTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
		} else {
			mLoadDataTask.execute();
		}
	}

	@Override
	public void onNavigationDrawerItemSelected(int position) {
		// update the main content by replacing fragments
		Fragment fragment;
	    FragmentManager fragmentManager = getFragmentManager(); // For AppCompat use getSupportFragmentManager
	    switch(position) {
	        default:
	        case 0:
	            fragment = new HomeFragment();
	            break;
	        case 1:
	            fragment = new CasesFragment();
	            break;
	        case 2:
	            fragment = new SubmitFragment();
	            break;
	        case 3:
	            fragment = new ErrorsFragment();
	            break;
	        case 4:
	            fragment = new ClientsFragment();
	            break;
	            
	    }
	    fragmentManager.beginTransaction()
	        .replace(R.id.container, fragment)
	        .commit();
	}


	static Menu menu;
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		if (!mNavigationDrawerFragment.isDrawerOpen()) {
			// Only show items in the action bar relevant to this screen
			// if the drawer is not showing. Otherwise, let the drawer
			// decide what to show in the action bar.
			getMenuInflater().inflate(R.menu.main, menu);
			MenuItem item = menu.findItem(R.id.action_example);
			if(MainActivity.FragPageTitle.equals("Support Cases")) {
				item.setVisible(true);
			} else {
				item.setVisible(false);
			}
			return true;
		}
		return super.onCreateOptionsMenu(menu);
	}
	
		
	

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		} else if (id == R.id.action_logout) {
			SharedPreferenceManager spm = new SharedPreferenceManager(MainActivity.this);
			spm.clearAll();
			Intent mainScreenIntent = new Intent(getApplicationContext(),LoginActivity.class);
			startActivity(mainScreenIntent);
			finish();
			return true;
		} else if (id == R.id.action_example) {
			showPopUpForScanner(this);
			
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	public void showPopUpForScanner(Context mContext) {
		
		LayoutInflater li = LayoutInflater.from(mContext);
		View promptsView = li.inflate(R.layout.dialogscanner, null);
		final LinearLayout llPanel1=(LinearLayout)promptsView.findViewById(R.id.ll1);
		final LinearLayout llPanel2=(LinearLayout)promptsView.findViewById(R.id.ll2);
		
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				mContext);
		final Spinner spinner=(Spinner)promptsView.findViewById(R.id.spinner1);
		String statuses[] = {"Open","Closed","WCA","CR Pending","All"};
	    ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
	            this, R.layout.spinner_item, statuses);
	    spinnerArrayAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
	    spinner.setAdapter(spinnerArrayAdapter);
    
	    final Spinner spinner2=(Spinner)promptsView.findViewById(R.id.spinner2);
        ArrayAdapter<String> spinnerArrayAdapter2 = new ArrayAdapter<String>(
	            this, R.layout.spinner_item, listItemInfo2);
	    spinnerArrayAdapter2.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
	    spinner2.setAdapter(spinnerArrayAdapter2);
	    
	    final Spinner spinner3=(Spinner)promptsView.findViewById(R.id.spinner3);
		String build[] = {"Support","Pre Go Live","All"};
	    ArrayAdapter<String> spinnerArrayAdapter3 = new ArrayAdapter<String>(
	            this, R.layout.spinner_item, build);
	    spinnerArrayAdapter3.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
	    spinner3.setAdapter(spinnerArrayAdapter3);
	    final EditText txt=(EditText)promptsView.findViewById(R.id.etSearch);
	    
	  
	    txt.addTextChangedListener(new TextWatcher() {

	        @Override
	        public void onTextChanged(CharSequence s, int start, int before,
	                int count) {
	            // TODO Auto-generated method stub
	            if (TextUtils.isEmpty(s.toString().trim())) {
	            	
	            	spinner.setSelection(0);
	            	spinner.setEnabled(true);
	            } else {
	            	
	            	spinner.setSelection(4);
	            	spinner.setEnabled(false);
            	
	            }
	        }
	        
	        @Override
	        public void beforeTextChanged(CharSequence s, int start, int count,
	                int after) {
	            // TODO Auto-generated method stub

	        }

	        @Override
	        public void afterTextChanged(Editable s) {

	        }
	    });
		final DatePicker dtFrom=(DatePicker)promptsView.findViewById(R.id.dpResult);
		final DatePicker dtTo=(DatePicker)promptsView.findViewById(R.id.dpResult2);
	    
		
	    final CheckBox chk=(CheckBox)promptsView.findViewById(R.id.checkBox1);
		chk.setOnCheckedChangeListener(new OnCheckedChangeListener()
		{
		    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
		    {
		        if ( isChecked )
		        {
		        	llPanel1.setVisibility(View.VISIBLE);
		        	llPanel2.setVisibility(View.VISIBLE);
		        } else {
		        	llPanel1.setVisibility(View.GONE);
		        	llPanel2.setVisibility(View.GONE);
		        }

		    }
		});
		

	    
	    // set prompts.xml to alertdialog builder
		alertDialogBuilder.setView(promptsView);

		// set dialog message
		alertDialogBuilder
			.setCancelable(false)
			.setPositiveButton("OK",
			  new DialogInterface.OnClickListener() {
			    public void onClick(DialogInterface dialog,int id) {
			    	CasesFragment cs = new CasesFragment();
			    	String clientList;
			    	if(spinner2.getSelectedItem().toString().equals("All Clients"))
			    	{
			    		clientList = "---Client List---";
			    	} else{
			    		clientList = spinner2.getSelectedItem().toString();
			    		}
			    	
			    	
			    	String fDate;
					String tDate;
					String fMonth;
					String fDay;
					String tMonth;
					String tDay;
					fDay = String.valueOf(dtFrom.getDayOfMonth());
					if(fDay.length() < 2) {
						fDay = "0"+fDay;
					}
					fMonth = String.valueOf(dtFrom.getMonth());
					if(fMonth.length() < 2) {
						fMonth = "0"+fMonth;
					}
				    int fYear =  dtFrom.getYear();

					tDay = String.valueOf(dtTo.getDayOfMonth());
					if(tDay.length() < 2) {
						tDay = "0"+tDay;
					}
					tMonth = String.valueOf(dtTo.getMonth());
					if(tMonth.length() < 2) {
						tMonth = "0"+tMonth;
					}
				    int tYear =  dtTo.getYear();
				    
				    if(chk.isChecked()) {
				    	 fDate = fYear+"-"+fDay+"-"+fMonth;
				    	 tDate = tYear+"-"+tDay+"-"+tMonth;
				    } else {
				    	
				    	fDate = "1800-01-01";
				    	tDate = "2222-02-01";
					}
				    
				    cs.refreshData(MainActivity.this, spinner.getSelectedItem().toString(), spinner2.getSelectedItem().toString(), spinner3.getSelectedItem().toString(), txt.getText().toString(), fDate, tDate);
			    }
			  })
			.setNegativeButton("Cancel",
			  new DialogInterface.OnClickListener() {
			    public void onClick(DialogInterface dialog,int id) {
				dialog.cancel();
			    }
			  });
		
	

		// create alert dialog
		AlertDialog alertDialog = alertDialogBuilder.create();
	 
		
		// show it
		alertDialog.show();
	}
	
	private class AsyncCallWS extends AsyncTask<String, Void, Void> {
	       
		Context context;
		
		public AsyncCallWS(Context mContext){
			this.context = mContext;
		}

		@Override
		protected void onPreExecute() {
			listItemInfo.clear();
			super.onPreExecute();
			if(!isCancelled()){
			}
			
		}
		
		@Override
        protected Void doInBackground(String... params) {
            //Create request
    	    SoapObject request = new SoapObject(Constants.NAMESPACE, METHOD_NAME);
    	    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
    	            SoapEnvelope.VER11);
    	    envelope.dotNet = true;
    	    //Set output SOAP object
    	    envelope.setOutputSoapObject(request);
    	    //Create HTTP call object
    	    HttpTransportSE androidHttpTransport = new HttpTransportSE(Constants.URL);
    	 
    	    try {
    	        //Invole web service
    	        androidHttpTransport.call(SOAP_ACTION, envelope);
                SoapObject response = (SoapObject) envelope.getResponse();
                for (int i = 0; i < response.getPropertyCount(); i++) {

                    Object property = response.getProperty(i);
                    SoapObject info = (SoapObject) property;
                    listItemInfo2.add(info.getProperty("ClientName").toString().trim());
     
                }
                
                listItemInfo2.add(0, "All Clients");
             
    	 
    	    } catch (Exception e) {
    	        e.printStackTrace();
    	    }
            return null;
        }
 
        @Override
        protected void onPostExecute(Void result) {
    		

        }
          
        }
	
}
