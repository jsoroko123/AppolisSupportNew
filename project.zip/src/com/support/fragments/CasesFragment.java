package com.support.fragments;

import java.util.ArrayList;
import java.util.Date;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Point;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.text.method.DateTimeKeyListener;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Toast;

import com.example.appolissupport.CaseDetails;
import com.example.appolissupport.LoginActivity;
import com.example.appolissupport.MainActivity;
import com.example.appolissupport.R;
import com.fortysevendeg.swipelistview.BaseSwipeListViewListener;
import com.fortysevendeg.swipelistview.SwipeListView;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshSwipeListView;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;
import com.support.adapters.CasesAdapter;
import com.support.objects.SupportCases;
import com.support.utilities.Constants;
import com.support.utilities.SharedPreferenceManager;

public class CasesFragment extends Fragment implements OnClickListener, OnItemClickListener {
	private final String METHOD_NAME = "ListSupportCases";
	private final String SOAP_ACTION = Constants.NAMESPACE+METHOD_NAME;
	public static String TAG = "PGGURU";
	private static PullToRefreshSwipeListView lvSupportCasesList;
	private SwipeListView swipeList;
	private ArrayList<SupportCases> listItemInfo = new ArrayList<SupportCases>();
	private CasesAdapter casesAdapter = null;

	private String ClientName;
	
    private static final String ARG_SECTION_NUMBER = "section_number";

    /**
    * Returns a new instance of this fragment for the given section number.
    */

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
    	MainActivity.FragPageTitle = "Support Cases";
        super.onActivityCreated(savedInstanceState);
        getActivity().getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        getActivity().getActionBar().setDisplayShowTitleEnabled(true);
        getActivity().getActionBar().setTitle(MainActivity.FragPageTitle);
    }
	
	public CasesFragment() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		SharedPreferenceManager spm = new SharedPreferenceManager(getActivity());
		View rootView = inflater.inflate(R.layout.fragment_cases, container,
				false);

		lvSupportCasesList = (PullToRefreshSwipeListView) rootView.findViewById(R.id.lv_support_cases);
		lvSupportCasesList.setMode(PullToRefreshBase.Mode.PULL_FROM_START);
		lvSupportCasesList.setOnItemClickListener(this);
		swipeList = lvSupportCasesList.getRefreshableView();
		if(spm.getBoolean("IsSupport", false)){
			ClientName = "0";
		} else {
			ClientName = spm.getString("ClientName", "");
		}
		setListData();
		lvSupportCasesList
				.setOnRefreshListener(new OnRefreshListener2<SwipeListView>() {

					@Override
					public void onPullDownToRefresh(
							PullToRefreshBase<SwipeListView> refreshView) {
						// TODO Auto-generated method stub
						String label = DateUtils.formatDateTime(
							getActivity(),
								System.currentTimeMillis(),
								DateUtils.FORMAT_SHOW_TIME
										| DateUtils.FORMAT_SHOW_DATE
										| DateUtils.FORMAT_ABBREV_ALL);
						// Update the LastUpdatedLabel
						refreshView.getLoadingLayoutProxy()
								.setLastUpdatedLabel(label);
						refreshData(getActivity(), "Open",ClientName, "Support", "", "1873-01-01", "2433-08-01");
					}

					@Override
					public void onPullUpToRefresh(
							PullToRefreshBase<SwipeListView> refreshView) {
					}
				});
		
		return rootView;
	}
	

	private class AsyncCallWS extends AsyncTask<String, Void, Void> {
       
		Context context;
		ProgressDialog progressDialog;
		String caseStatus;
		String client;
		String type;
		String search;
		String from;
		String to;
		
		public AsyncCallWS(Context mContext, String mcaseStatus, String mClient, String mType, String mSearch, String mFrom, String mTo){
			this.context = mContext;
			this.caseStatus = mcaseStatus;
			this.client = mClient;
			this.type = mType;
			this.search = mSearch;
			this.from = mFrom;
			this.to = mTo;
		}

		@Override
		protected void onPreExecute() {
			listItemInfo.clear();
			super.onPreExecute();
			if(!isCancelled()){
				progressDialog = new ProgressDialog(context);
				progressDialog.setMessage("Loading...");
				progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
	
							@Override
							public void onCancel(DialogInterface dialog) {
								cancel(true);
							}
						});
				progressDialog.setCanceledOnTouchOutside(false);
				progressDialog.setCancelable(false);
				progressDialog.show();
			}
			
		}
		
		@Override
        protected Void doInBackground(String... params) {
            Log.i(TAG, "doInBackground");
            //Create request
    	    SoapObject request = new SoapObject(Constants.NAMESPACE, METHOD_NAME);
    	    //Property which holds input parameters
    	    PropertyInfo supportCasesPI = new PropertyInfo();
    	    supportCasesPI.setName("ClientName");
    	    supportCasesPI.setValue(client);
    	    supportCasesPI.setType(String.class);
    	    request.addProperty(supportCasesPI);
    	    
    	    supportCasesPI = new PropertyInfo();
    	    supportCasesPI.setName("status");
    	    supportCasesPI.setValue(caseStatus);
    	    supportCasesPI.setType(String.class);
    	    request.addProperty(supportCasesPI);
    	    
    	    supportCasesPI = new PropertyInfo();
    	    supportCasesPI.setName("viewOption");
    	    supportCasesPI.setValue(type);
    	    supportCasesPI.setType(String.class);
    	    request.addProperty(supportCasesPI);
    	   
    	    supportCasesPI = new PropertyInfo();
    	    supportCasesPI.setName("search");
    	    supportCasesPI.setValue(search);
    	    supportCasesPI.setType(String.class);
    	    request.addProperty(supportCasesPI);
    	
    	    supportCasesPI = new PropertyInfo();
    	    supportCasesPI.setName("supportUserID");
    	    supportCasesPI.setValue(0);
    	    supportCasesPI.setType(int.class);
    	    request.addProperty(supportCasesPI);
    	    
    	    supportCasesPI = new PropertyInfo();
    	    supportCasesPI.setName("isSupport");
    	    supportCasesPI.setValue(true);
    	    supportCasesPI.setType(Boolean.class);
    	    request.addProperty(supportCasesPI);
    	    
    	    supportCasesPI = new PropertyInfo();
    	    supportCasesPI.setName("loggedUserId");
    	    supportCasesPI.setValue(56);
    	    supportCasesPI.setType(int.class);
    	    request.addProperty(supportCasesPI);
    	    
    	    supportCasesPI = new PropertyInfo();
    	    supportCasesPI.setName("begin");
    	    supportCasesPI.setValue(from);
    	    supportCasesPI.setType(Date.class);
    	    request.addProperty(supportCasesPI);
    	    
    	    supportCasesPI = new PropertyInfo();
    	    supportCasesPI.setName("end");
    	    supportCasesPI.setValue(to);
    	    supportCasesPI.setType(Date.class);
    	    request.addProperty(supportCasesPI);

    	    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
    	            SoapEnvelope.VER11);
    	    envelope.dotNet = true;
    	    //Set output SOAP object
    	    envelope.setOutputSoapObject(request);
    	    //Create HTTP call object
    	    HttpTransportSE androidHttpTransport = new HttpTransportSE(Constants.URL);
    	 
    	    try {
    	        //Invole web service
    	        androidHttpTransport.call(SOAP_ACTION, envelope);
                SoapObject response = (SoapObject) envelope.getResponse();
                for (int i = 0; i < response.getPropertyCount(); i++) {

                    Object property = response.getProperty(i);
                    SoapObject info = (SoapObject) property;
                    SupportCases cases = new SupportCases();
                    cases.setCaseNumber(info.getProperty("CaseNumber").toString().trim());
                    cases.setIssue(info.getProperty("Issue").toString().trim());
                    cases.setClient(info.getProperty("Client").toString().trim());
                    cases.setClientContact(info.getProperty("ClientContact").toString().trim());
                    cases.setDateCreated(info.getProperty("DateCreated").toString().trim());
                    cases.setSeverity(info.getProperty("Severity").toString().trim());
                    cases.setStatus(info.getProperty("Status").toString().trim());
                    cases.setAssigned(info.getProperty("SupportUser").toString().trim());
                    cases.setReplied(info.getProperty("Replied").toString().trim());
                    cases.setAttachment(Boolean.valueOf(info.getProperty("HasAttachment").toString().trim()));
                    listItemInfo.add(cases);
                }
    	 
    	    } catch (Exception e) {
    	        e.printStackTrace();
    	    }
            return null;
        }
 
        @Override
        protected void onPostExecute(Void result) {
            Log.i(TAG, "onPostExecute");
            if(null != progressDialog && (progressDialog.isShowing())){
				progressDialog.dismiss();
			}
            
            
            
            if(null != lvSupportCasesList){
            	lvSupportCasesList.onRefreshComplete();
			}
            casesAdapter = new CasesAdapter(context,
    				listItemInfo);
    		lvSupportCasesList.setAdapter(casesAdapter);
    		casesAdapter.notifyDataSetChanged();

			
          
        }
 
        @Override
        protected void onProgressUpdate(Void... values) {
            Log.i(TAG, "onProgressUpdate");
        }
 
    }
	
	public void refreshData(Context context, String caseStatus, String client, String type, String search, String from, String to) {
		AsyncCallWS mLoadDataTask = new AsyncCallWS(context, caseStatus, client, type, search, from, to);

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			mLoadDataTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
		} else {
			mLoadDataTask.execute();
		}
	}
	
	
	private void setListData() {
		refreshData(getActivity(), "Open",ClientName, "Support", "","1893-01-01","2456-07-31");
		swipeList.setSwipeListViewListener(new BaseSwipeListViewListener() {
			@Override
			public void onClickFrontView(final int position) {
				
				Intent intentAcquire = new Intent(getActivity(), CaseDetails.class);
				intentAcquire.putExtra("CaseID", casesAdapter.getItem(position-1).getCaseNumber());
				((Activity)getActivity()).startActivityForResult(intentAcquire, 1);
			}

			@Override
			public void onClickBackView(final int position) {
				
			}

			@Override
			public void onOpened(int position, boolean toRight) {
				// TODO Auto-generated method stub
				super.onOpened(position - 1, toRight);
			}

			@Override
			public void onMove(int position, float x) {
				// TODO Auto-generated method stub
				super.onMove(position - 1, x);
			}

			@Override
			public int onChangeSwipeMode(int position) {
				// TODO Auto-generated method stub
				return SwipeListView.SWIPE_MODE_DEFAULT;
			}

			@Override
			public void onStartOpen(int position, int action, boolean right) {
				// TODO Auto-generated method stub
				super.onStartOpen(position - 1, action, right);

			}
		});
		try{
			Display display = getActivity().getWindowManager().getDefaultDisplay();
			Point size = new Point();
			display.getSize(size);
			int width = size.x;
			swipeList.setOffsetLeft(0-width);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		lvSupportCasesList.setLongClickable(true);
		swipeList.setSwipeOpenOnLongPress(false);
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
	
	}

	@Override
	public void onClick(View v) {
	
	}
	
   

	


	

}